#include <stdio.h>

struct bankacc{
    int accNo;
    char name[34];
    char ifsc[12];
    float balance; 
};

int main(){
    
    return 0;
}