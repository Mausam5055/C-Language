#include <stdio.h>

int main(){
    // Problem: Print Happy Birthday 1 Lakh times
    printf("Happy Birthday!\n"); 
    return 0;
}