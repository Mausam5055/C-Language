#include <stdio.h>

int main(){
    int i = 0;
    while(i<4){
        printf("Happy Birthday!\n");
        // i = i + 1;
        i++;
    }
    return 0;
}