#include<stdio.h>

int main(){
    int a; // Variable declaration
    a = 6; // Variable initialization
    printf("The output of this program is %d", a);
    return 0;
}