#include <stdio.h>

int main()
{
    // Which of the following is invalid in C?
    int a = 1;
    int b = a;
    int v = 3 * 3;
    // char dt = '21 dec 2020'; // Wrong!
    return 0;
}