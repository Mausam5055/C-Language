#include <stdio.h>

int main(){
    float a = 3.0/8 - 2;
    printf("The value of a is %f", a);
    return 0;
}